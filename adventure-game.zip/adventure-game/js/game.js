var inventory = [];

function iOpen(){
    console.log("opening inventory");
    if (inventory.includes("pipboy")) {
        document.getElementById('pipboy-I').style.display="block";
    } else {
        document.getElementById('pipboy-I').style.display="none";
    }
    if (inventory.includes("pistol")) {
        document.getElementById('pistol-I').style.display="block";
    } else {
        document.getElementById('pistol-I').style.display="none";
    }
    document.getElementById("I-knop").onclick = iClose;
}

function iClose(){
    console.log("closing inventory");
    document.getElementById("pipboy-I").style.display="none";
    document.getElementById("pistol-I").style.display="none";
    document.getElementById("I-knop").onclick = iOpen;
}

function restart () {
    console.log("reloading site");
    location.reload();
}

function start(){
    console.log('start');
    document.getElementById("knop1").onclick = level1;
}
console.log('call start');
start();


function level1(){
    console.log("loading level1");
    document.getElementById("I-knop").style.display="block";
    document.getElementById('text-h').innerHTML ='You awake at the sound of sirens.';
    document.getElementById('text').innerHTML ='A nuclear war has started';
    document.body.style.background="url('img/Fallout-1.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Go to vault 111.';
    document.getElementById("knop1").onclick = level2;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Stay in your house.';
    document.getElementById("knop2").onclick = levelEnd1;
}

function levelEnd1(){
    console.log("loading levelEnd1");
    document.getElementById('knop2').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='The bombs blew you away with pure heat.';
    document.body.style.background="url('img/Fallout-End1.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level2(){
    console.log("loading level2");
    document.getElementById('text-h').innerHTML ='Inside the vault.';
    document.getElementById('text').innerHTML ='You get asked to step into a decontamination pod';
    document.body.style.background="url('img/Fallout-cryo.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Step in.';
    document.getElementById("knop1").onclick = level3;
    document.getElementById("knop2").style.display="none";
}

function level3(){
    console.log("loading level3");
    document.getElementById('text-h').innerHTML ='Your pod opens.';
    document.getElementById('text').innerHTML ='You wake up with a headache and look around.';
    document.body.style.background="url('img/Fallout-cryo-room.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Walk out of the room.';
    document.getElementById("knop1").onclick = level4;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Examine the pods';
    document.getElementById("knop2").onclick = level31;
}

function level31(){
    console.log("loading level31");
    document.getElementById('text-h').innerHTML ='Inside the vault.';
    document.getElementById('text').innerHTML ='The pods appear to be cryo-pods';
    document.body.style.background="url('img/Fallout-cryo-room-check.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Walk out of the room.';
    document.getElementById("knop1").onclick = level4;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Step back into your cryo-pod.';
    document.getElementById("knop2").onclick = levelEnd2;
}

function levelEnd2(){
    console.log("loading levelEnd2");
    document.getElementById('text-h').innerHTML ='Unknown year.';
    document.getElementById('text').innerHTML ='You get woken up by a search-team, thousands of yours later. After the world had been rebuild. (The End)';
    document.body.style.background="url('img/Fallout-End2.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level4(){
    console.log("loading level4");
    document.getElementById('text-h').innerHTML ='Everyone is dead!';
    document.getElementById('text').innerHTML ='You have got to find a way out of the vault.';
    document.body.style.background="url('img/Fallout-2.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Walk into the next room.';
    document.getElementById("knop1").onclick = level5;
    document.getElementById("knop2").style.display="none";
}

function level5(){
    console.log("loading level5");
    document.getElementById('text-h').innerHTML ='You found the vault door.';
    document.getElementById('text').innerHTML ='But how can you open it?';
    document.body.style.background="url('img/Fallout-vault.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Try to open the vault door by hand.';
    document.getElementById("knop1").onclick = levelEnd3;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Search the vault.';
    document.getElementById("knop2").onclick = level6;
}

function levelEnd3(){
    console.log("loading levelEnd3");
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='You got a electrical shock from the vault door.';
    document.body.style.background="url('img/Fallout-d.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level6(){
    console.log("loading level6");
    document.getElementById('text-h').innerHTML ='Searching';
    document.getElementById('text').innerHTML ='What will you do?';
    document.body.style.background="url('img/Fallout-vault.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Try to blow open the vault door.';
    document.getElementById("knop1").onclick = levelEnd4;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Use control-panel.';
    document.getElementById('pipboy').style.display="block";
    pipboy.onclick=function(){
        pipboy.style.display="none";
        inventory.push("pipboy");
    };

    knop2.onclick=function(){
        if (inventory.includes("pipboy")){
            level7();
        } else {
            alert("Nothing happens.");
        }
    };
}

function levelEnd4(){
    console.log("loading levelEnd4");
    document.getElementById('pipboy').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='The shrapnel bounced of the metal walls and hit you.';
    document.body.style.background="url('img/Fallout-End4.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level7(){
    console.log("loading level7");
    document.getElementById('pipboy').style.display="none";
    document.getElementById('text-h').innerHTML ='In front of you you see a broken world!';
    document.getElementById('text').innerHTML ='Where will you go?';
    document.body.style.background="url('img/Fallout-broken.png')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Go check on your house.';
    document.getElementById("knop1").onclick = level8;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Try to go back into the vault.';
    document.getElementById("knop2").onclick = level3;
    knop2.onclick=function(){
        alert("You dont know how!")
    };
}

function level8(){
    console.log("loading level8");
    document.getElementById('text-h').innerHTML ='Your home is destroyed.';
    document.getElementById('text').innerHTML ='You hear a sound coming from your house';
    document.body.style.background="url('img/Fallout-house.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Walk away.';
    document.getElementById("knop1").onclick = level10;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Check out the sound.';
    document.getElementById("knop2").onclick = level9;
}

function level9(){
    console.log("loading level9");
    document.getElementById('text-h').innerHTML ='Its your robot codsworth!';
    document.getElementById('text').innerHTML ='He says that he knows how to survive the wasteland together.';
    document.body.style.background="url('img/Fallout-codsworth.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Walk away.';
    document.getElementById("knop1").onclick = level10;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Survive together.';
    document.getElementById("knop2").onclick = levelEnd5;
}

function levelEnd5(){
    console.log("loading levelEnd5");
    document.getElementById('text-h').innerHTML ='You survive the wasteland together with your robot codsworth!';
    document.getElementById('text').innerHTML ='Building farms and rebuilding your house.';
    document.body.style.background="url('img/Fallout-End2.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level10(){
    console.log("loading level10");
    document.getElementById('text-h').innerHTML ='Someone shouts for help!';
    document.getElementById('text').innerHTML ='He is being attacked by a gang of crazy people.';
    document.body.style.background="url('img/Fallout-concord-1.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Walk away.';
    document.getElementById("knop1").onclick = levelEnd6;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Help them.';
    document.getElementById("knop2").onclick = level11;
}

function levelEnd6(){
    console.log("loading levelEnd6");
    document.getElementById('pistol').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='You ran over a mine and got blown up';
    document.body.style.background="url('img/Fallout-landmine.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level11(){
    console.log("loading level11");
    document.getElementById('text-h').innerHTML ='The people of te gang have weapons!';
    document.getElementById('text').innerHTML ='What will you do?';
    document.body.style.background="url('img/Fallout-concord.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Flee.';
    document.getElementById("knop1").onclick = levelEnd7;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Attack.';
    document.getElementById("knop2").onclick = level12;
    document.getElementById('pistol').style.display="block";
    pistol.onclick=function(){
        pistol.style.display="none";
        inventory.push("pistol");
    };

    knop2.onclick=function(){
        if (inventory.includes("pistol")){
            level12();
        } else {
            levelEnd7()
        }
    }
}

function levelEnd7(){
    console.log("loading levelEnd7");
    document.getElementById('pistol').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='You got shot and bled to death.';
    document.body.style.background="url('img/Fallout-shot.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}

function level12(){
    console.log("loading level12");
    document.getElementById('text-h').innerHTML ='You killed the gang!';
    document.getElementById('text').innerHTML ='After meeting the people you saved one of them asks you if you want to join the group.';
    document.body.style.background="url('img/Fallout-preston.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").style.display="block";
    document.getElementById("knop1").innerHTML ='Accept his offer.';
    document.getElementById("knop1").onclick = levelEnd8;
    document.getElementById("knop2").style.display="block";
    document.getElementById("knop2").innerHTML ='Try to survive on your own.';
    document.getElementById("knop2").onclick = levelEnd9;
}

function levelEnd8(){
    console.log("loading levelEnd8");
    document.getElementById('text-h').innerHTML ='You survive the rest of your days in the wasteland.';
    document.getElementById('text').innerHTML ='Together with your new friends you were able to live a long life.';
    document.body.style.background="url('img/Fallout-together.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";}

function levelEnd9(){
    console.log("loading levelEnd9");
    document.getElementById('text-h').innerHTML ='You survive the rest of your days in the wasteland.';
    document.getElementById('text').innerHTML ='On your own you were no able to survive the rough conditions of the wasteland and died after 5 mouths.';
    document.body.style.background="url('img/Fallout-alone.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById("knop1").innerHTML ='Restart';
    document.getElementById("knop1").onclick = restart;
    document.getElementById("knop2").style.display="none";
}