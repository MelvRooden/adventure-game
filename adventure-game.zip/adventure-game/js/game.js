var inventory = [];

function iOpen(){
    if (inventory.includes("pipboy")) {
        document.getElementById('pipboy-I').style.display="block";
    } else {
        document.getElementById('pipboy-I').style.display="none";
    }
    if (inventory.includes("pistol")) {
        document.getElementById('pistol-I').style.display="block";
    } else {
        document.getElementById('pistol-I').style.display="none";
    }
    document.getElementById("inventory-js-open").style.display="none";
    document.getElementById('inventory-js-close').style.display="block";
}

function iClose(){
    document.getElementById("inventory-js-close").style.display="none";
    document.getElementById("pipboy-I").style.display="none";
    document.getElementById("pistol-I").style.display="none";
    document.getElementById("inventory-js-open").style.display="block";
    document.getElementById('inventory-js-close').style.display="close";
}

function restart () {
    location.reload();
}


function level1(){
    document.getElementById('knop1').style.display="none";
    document.getElementById('text-h').innerHTML ='You awake at the sound of sirens.';
    document.getElementById('text').innerHTML ='A nuclear war has started';
    document.body.style.background="url('img/Fallout-1.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop2').style.display="block";
    document.getElementById('knop3').style.display="block";
}

function levelEnd1(){
    document.getElementById('knop2').style.display="none";
    document.getElementById('knop3').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='The bombs blew you away with pure heat.';
    document.body.style.background="url('img/Fallout-End1.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function level2(){
    document.getElementById('knop2').style.display="none";
    document.getElementById('knop3').style.display="none";
    document.getElementById('text-h').innerHTML ='Inside the vault.';
    document.getElementById('text').innerHTML ='You get asked to step into a decontamination pod';
    document.body.style.background="url('img/Fallout-cryo.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop4').style.display="block";
}

function level3(){
    document.getElementById('knop4').style.display="none";
    document.getElementById('text-h').innerHTML ='Your pod opens.';
    document.getElementById('text').innerHTML ='You wake up with a headache and look around.';
    document.body.style.background="url('img/Fallout-cryo-room.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop5').style.display="block";
    document.getElementById('knop6').style.display="block";
}

function level31(){
    document.getElementById('knop6').style.display="none";
    document.getElementById('text-h').innerHTML ='Inside the vault.';
    document.getElementById('text').innerHTML ='The pods appear to be cryo-pods';
    document.body.style.background="url('img/Fallout-cryo-room-check.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop7').style.display="block";
}

function levelEnd2(){
    document.getElementById('knop5').style.display="none";
    document.getElementById('knop7').style.display="none";
    document.getElementById('text-h').innerHTML ='Unknown year.';
    document.getElementById('text').innerHTML ='You get woken up by a search-team, thousands of yours later. After the world had been rebuild. (The End)';
    document.body.style.background="url('img/Fallout-End2.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function level4(){
    document.getElementById('knop5').style.display="none";
    document.getElementById('knop6').style.display="none";
    document.getElementById('knop7').style.display="none";
    document.getElementById('text-h').innerHTML ='Everyone is dead!';
    document.getElementById('text').innerHTML ='You have got to find a way out of the vault.';
    document.body.style.background="url('img/Fallout-2.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop8').style.display="block";
}

function level5(){
    document.getElementById('knop8').style.display="none";
    document.getElementById('text-h').innerHTML ='You found the vault door.';
    document.getElementById('text').innerHTML ='But how can you open it?';
    document.body.style.background="url('img/Fallout-vault.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop9').style.display="block";
    document.getElementById('knop10').style.display="block";
}

function levelEnd3(){
    document.getElementById('knop9').style.display="none";
    document.getElementById('knop10').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='You got a electrical shock from the vault door.';
    document.body.style.background="url('img/Fallout-d.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function level6(){
    document.getElementById('knop9').style.display="none";
    document.getElementById('knop10').style.display="none";
    document.getElementById('text-h').innerHTML ='Searching';
    document.getElementById('text').innerHTML ='What will you do?';
    document.getElementById('knop11').style.display="block";
    document.getElementById('knop12').style.display="block";
    document.getElementById('pipboy').style.display="block";
    pipboy.onclick=function(){
        pipboy.style.display="none";
        inventory.push("pipboy");
    };

    knop12.onclick=function(){
        if (inventory.includes("pipboy")){
            level17();
        } else {
            alert("Nothing happens.");
        }
    }
}

function levelEnd4(){
    document.getElementById('knop11').style.display="none";
    document.getElementById('knop12').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='The shrapnel bounced of the metal walls and hit you.';
    document.body.style.background="url('img/Fallout-End4.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('pipboy').style.display="none";
    document.getElementById('knop-restart').style.display="block";
}

function level17(){
    document.getElementById('knop11').style.display="none";
    document.getElementById('knop12').style.display="none";
    document.getElementById('text-h').innerHTML ='In front of you you see a broken world!';
    document.getElementById('text').innerHTML ='Where will you go?';
    document.body.style.background="url('img/Fallout-broken.png')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop13').style.display="block";
    document.getElementById('knop14').style.display="block";
    knop14.onclick=function(){
        alert("You dont know how!")
    }
}

function level18(){
    document.getElementById('knop13').style.display="none";
    document.getElementById('knop14').style.display="none";
    document.getElementById('text-h').innerHTML ='Your home is destroyed.';
    document.getElementById('text').innerHTML ='You hear a sound coming from your house';
    document.body.style.background="url('img/Fallout-house.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop15').style.display="block";
    document.getElementById('knop16').style.display="block";
}

function level19(){
    document.getElementById('knop15').style.display="none";
    document.getElementById('knop16').style.display="none";
    document.getElementById('text-h').innerHTML ='Its your robot codsworth!';
    document.getElementById('text').innerHTML ='He says that he knows how to survive the wasteland together.';
    document.body.style.background="url('img/Fallout-codsworth.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop17').style.display="block";
    document.getElementById('knop18').style.display="block";
}

function levelend5() {
    document.getElementById('knop17').style.display="none";
    document.getElementById('knop18').style.display="none";
    document.getElementById('text-h').innerHTML ='You survive the wasteland together with your robot codsworth!';
    document.getElementById('text').innerHTML ='';
    document.body.style.background="url('img/Fallout-End2.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function level20(){
    document.getElementById('knop15').style.display="none";
    document.getElementById('knop16').style.display="none";
    document.getElementById('knop17').style.display="none";
    document.getElementById('knop18').style.display="none";
    document.getElementById('text-h').innerHTML ='Someone shouts for help!';
    document.getElementById('text').innerHTML ='He is being attacked by a gang of crazy people.';
    document.body.style.background="url('img/Fallout-concord-1.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop19').style.display="block";
    document.getElementById('knop20').style.display="block";
}

function levelend6(){
    document.getElementById('knop19').style.display="none";
    document.getElementById('knop20').style.display="none";
    document.getElementById('knop22').style.display="none";
    document.getElementById('pistol').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='You ran over a mine and got blown up';
    document.body.style.background="url('img/Fallout-landmine.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function level21(){
    document.getElementById('knop19').style.display="none";
    document.getElementById('text-h').innerHTML ='The people of te gang have weapons!';
    document.getElementById('text').innerHTML ='What will you do?';
    document.body.style.background="url('img/Fallout-concord.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop21').style.display="block";
    document.getElementById('pistol').style.display="block";
    pistol.onclick=function(){
        pistol.style.display="none";
        inventory.push("pistol");
    };

    knop21.onclick=function(){
        if (inventory.includes("pistol")){
            level22();
        } else {
            levelend7();
        }
    }
}

function levelend7(){
    document.getElementById('knop20').style.display="none";
    document.getElementById('knop21').style.display="none";
    document.getElementById('knop22').style.display="none";
    document.getElementById('pistol').style.display="none";
    document.getElementById('text-h').innerHTML ='You Died!';
    document.getElementById('text').innerHTML ='You got shot and bled to death.';
    document.body.style.background="url('img/Fallout-shot.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function level22(){
    document.getElementById('knop21').style.display="none";
    document.getElementById('knop20').style.display="none";
    document.getElementById('text-h').innerHTML ='You killed the gang!';
    document.getElementById('text').innerHTML ='After meeting the people you saved one of them asks you if you want to join the group.';
    document.body.style.background="url('img/Fallout-preston.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop22').style.display="block";
    document.getElementById('knop23').style.display="block";
}

function levelend8(){
    document.getElementById('knop22').style.display="none";
    document.getElementById('knop23').style.display="none";
    document.getElementById('text-h').innerHTML ='You survive the rest of your days in the wasteland.';
    document.getElementById('text').innerHTML ='Together with your new friends you were able to live a long life.';
    document.body.style.background="url('img/Fallout-together.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}

function levelend9(){
    document.getElementById('knop22').style.display="none";
    document.getElementById('knop23').style.display="none";
    document.getElementById('text-h').innerHTML ='You survive the rest of your days in the wasteland.';
    document.getElementById('text').innerHTML ='On your own you were no able to survive the rough conditions of the wasteland and died after 5 mouths.';
    document.body.style.background="url('img/Fallout-alone.jpg')";
    document.body.style.backgroundSize='cover';
    document.getElementById('knop-restart').style.display="block";
}